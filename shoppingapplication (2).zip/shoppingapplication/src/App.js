import logo from './logo.svg';
import './App.css';
import Signup from './Components/Signup';
import Login from './Components/Login';
import ProductList from './Components/ProductList';
import react, {useState} from 'react';
import { Route, Router, Routes } from 'react-router-dom';
import CartView from './Components/CartView';
import { CartProvider } from './Components/CartContext';

function App() {
  const [users, setUsers] = useState([]);
  const [authenticated, setAuthenticated] = useState(false);
  const [page, setPage] = useState('login');
  const[view,setView] = useState('ProductList');

  const Navigate = (view) => {
    setView(view);
  }
 
  const navigate = (page) => {
    setPage(page);
  };
  return (
    <div className="App">
      {page === 'signup' && <Signup setUsers={setUsers} navigate={navigate} />}
      {page === 'login' && <Login users={users} setAuthenticated={setAuthenticated} navigate={navigate} />}
      {page === 'products' && authenticated && <ProductList/>}
      {page === 'products' && !authenticated && <Login users={users} setAuthenticated={setAuthenticated} navigate={navigate} />}
    </div>
  );
};

export default App;
