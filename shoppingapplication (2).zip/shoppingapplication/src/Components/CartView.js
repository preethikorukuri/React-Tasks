import React, { useContext } from 'react';
import { CartContext, useCart } from './CartContext';
import { Navigate } from 'react-router-dom';
 
const CartView = ({navigateTo}) => {
  const { cart, removeFromCart } = useContext(CartContext);

  const placeOrder = () => {
    alert('Order placed');
    Navigate('productList');
  }
 
  return (
    <div>
      <h1>Your Cart</h1>
      <table border="1">
        <thead>
          <tr>
            <th>Id</th>
            <th>UserId</th>
            <th>Product Id</th>
            <th>Product Name</th>
            <th>Product Price</th>
            <th>Quantity</th>
            <th>SumTotal</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {cart.map((item, index) => (
            <tr key={index}>
                <td>{index + 1}</td>
                <td>1</td>
                <td>{item.id}</td>
                <td>{item.name}</td>
                <td>{item.price}</td>
                <td>{item.quantity}</td>
                <td>{item.price * item.quantity}</td>
                <td>
                    <button onClick={() => removeFromCart(index)}>Remove</button>
                </td>
            </tr>
          ))}
        </tbody>
      </table>
      <button onClick={placeOrder}>Place Order</button>
      <button onClick={() => Navigate('productList')}>Back to ProductList</button>
    </div>
  );
};
 
export default CartView;