import React, { useState } from 'react';
 
const Login = ({ users, setAuthenticated, navigate }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
 
  const handleSubmit = (e) => {
    e.preventDefault();
    const user = users.find((u) => u.email === email && u.password === password);
    if (user) {
      setAuthenticated(true);
      navigate("products");
    } else {
      alert("Invalid credentials");
    }
  };
 
  return (
    <div>
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />{" "}
        <br></br>
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />{" "}
        <br></br>
        <button type="submit">Login</button> &nbsp;
        <button type="button" onClick={() => navigate("signup")}>
          Register
        </button>
      </form>
    </div>
  );
};
 
export default Login;

 