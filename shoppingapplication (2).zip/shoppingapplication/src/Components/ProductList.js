import React, { useContext } from 'react';
import products from './products.json';
import { CartContext, useCart } from './CartContext';
import { Link, Navigate } from 'react-router-dom';
import CartView from './CartView';
 
const ProductList = ({navigateTo}) => {
    const{addToCart} = useContext(CartContext);

    const handleAddToCart =(product) => {
        addToCart({...product,quantity:1});
        alert("added to cart");
    };

    const viewCart = () => {
        Navigate('cart');
    }

  return (
    <div>
      <h1>Product List</h1>
      <table border="1">
        <thead>
          <tr>
            <th>Product Id</th>
            <th>Product Name</th>
            <th>Product Price</th>
            <th>Product Description</th>
            <th>Product Image Url</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {products.map((product) => (
            <tr key={product.id}>
                <td>{product.id}</td>
                <td>{product.name}</td>
                <td>{product.price}</td>
                <td>{product.description}</td>
                <td><img src={product.imageUrl} alt={product.name} width="100%"></img></td>
                <td>
                    <button onClick={() => handleAddToCart(product)}>Add To Cart</button>
                </td>
            </tr>
          ))}
        </tbody>
      </table> <br/>
       <button onClick={viewCart}>View Cart</button>
    </div>
  );
};
 
export default ProductList;

//onClick={() => addToCart(product)}
// const {addToCart} = useCart();